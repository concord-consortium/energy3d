Energy3D

This software is developed by The Concord Consortium (http://www.concord.org/). 
It allows construction of 3D houses, study the effect of sun with its accurate 
heliodon, and print the house in its flattened form.

This software runs on any Windows or Mac OS that has Java 6 installed in it. If
your computer does not have Java you may download it free from this website:

http://www.java.com/getjava/

Instructions:
- To start the Energy3D simply double-click on energy3d.jar file.

If you require assistance or have suggestions on how to improve Energy3D please 
contact us by email:

Dr. Saeid Nourian
snourian@concord.org

Dr. Charles Xie
qxie@concord.org

http://www.concord.org/